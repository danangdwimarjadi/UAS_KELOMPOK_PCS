package com.example.toko.response.transaksi

data class Data(
    val transaksi: List<Transaksi>,
    val total: String
)