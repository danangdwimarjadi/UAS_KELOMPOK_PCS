package com.example.toko.response.login

data class Data(
    val admin : Admin,
    val token : String
)
