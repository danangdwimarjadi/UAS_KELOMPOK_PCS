package com.example.toko.response.itempembelian


    data class ItemPembelianResponse(
val `data`: Data,
val message: String,
val success: Boolean
)

