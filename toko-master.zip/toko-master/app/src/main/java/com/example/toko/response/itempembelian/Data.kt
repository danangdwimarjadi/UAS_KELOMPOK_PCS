package com.example.toko.response.itempembelian

data class Data(
    val pembelian: ItemPembelian
)