package com.example.toko.adapter

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.example.toko.CallbackInterface
import com.example.toko.LoginActivity
import com.example.toko.R
import com.example.toko.response.cart.Cart
import com.example.toko.response.produk.Produk
import com.example.toko.response.produk.ProdukResponsePost
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TransaksiAdapter( val listProduk: List<Produk>): RecyclerView.Adapter<TransaksiAdapter.ViewHolder>() {

    var callbackInterface : CallbackInterface? = null
    var total:Int = 0
    var cart : ArrayList<Cart> = arrayListOf<Cart>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_transaksi, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val produk = listProduk[position]
        holder.txtNamaProduk.text = produk.nama
        holder.txtHarga.text = produk.harga

        holder.btnPlus.setOnClickListener{
            val old_value = holder.txtQty.text.toString().toInt()
            val new_value = old_value+1

            holder.txtQty.setText(new_value.toString())

            total = total + produk.harga.toString().toInt()
            val index = cart.indexOfFirst { it.id==produk.id.toInt() }.toInt()

            if(index !=-1){
                cart.removeAt(index)
            }


            val itemCart = Cart(produk.id.toInt(),produk.harga.toInt(),new_value)
            cart.add(itemCart)

            callbackInterface?.passResultCallback(total.toString(), cart )


        }
        holder.btnMinus.setOnClickListener {
            val old_value = holder.txtQty.text.toString().toInt()
            val new_value = old_value-1
            val index = cart.indexOfFirst { it.id==produk.id.toInt() }.toInt()
            if(index !=-1){
                cart.removeAt(index)
            }
            if(new_value>= 0){
                holder.txtQty.setText(new_value.toString())

                total = total - produk.harga.toString().toInt()


            }
            if(new_value >=1){
                val itemCart = Cart(produk.id.toInt(),produk.harga.toInt(),new_value)
                cart.add(itemCart)
            }

            callbackInterface?.passResultCallback(total.toString(), cart )

        }

    }




    override fun getItemCount(): Int {
        return listProduk.size
    }

    class ViewHolder(itemViem: View) : RecyclerView.ViewHolder(itemViem) {
        val txtNamaProduk = itemViem.findViewById(R.id.txtNamaProduk) as TextView
        val txtHarga = itemViem.findViewById(R.id.txtHarga) as TextView
        val btnPlus = itemViem.findViewById(R.id.btnPlus) as ImageButton
        val btnMinus = itemViem.findViewById(R.id.btnMinus) as ImageButton
        val txtQty = itemView.findViewById(R.id.txtQty) as TextView
    }
}