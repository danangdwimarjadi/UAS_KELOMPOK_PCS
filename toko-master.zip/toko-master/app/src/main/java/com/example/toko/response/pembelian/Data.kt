package com.example.toko.response.pembelian


data class Data(
    val pembelian: List<Pembelian>
)